
import './App.css';
import React, { useState } from 'react';

function App() {

  const [rtoInputs, setRTOInpust] = useState({
      iA: "",
      iB: "",
      iC: "",
      iD: "",
      iE: "",
      iF: "",
      // iG: 0,
      // iH: 0,
      // iI: 0
    })

    const [gg, setGG] = useState(0);
    const [hh, setHH] = useState(0);
    const [ii, setII] = useState(0);


    const handleOnChange = (data) => {
      //console.log(data.target.name);
      const {name, value} = data.target;
      setRTOInpust({...rtoInputs, [name]: parseInt(value)});

      if(rtoInputs.iA && rtoInputs.iB && rtoInputs.iC && rtoInputs.iD && rtoInputs.iE && rtoInputs.iF){
        console.log("rtoInputs", rtoInputs);
        
        /* const A = 10; //Total Number of monthly orders
        const B = 25; //Current RTO %
        const C = 250; //Avg Fwd Ship Cost
        const D = 175;  //Avg RTO Ship Cost
        const E = 15; //Avg margin per order
        const F = 1; //RTO reduced to
        
        const G = ((A * (B/100)) * (C + D + E)); //Monthly RTO Loss
        
        const H  = G - [((A * (F/100)) * (C+D+E)) + ((((B-F) / 100) * A) * C)];
        
        const I = (H / A); //Per Order Saving
        
        console.log("Savings... ", I); */

        let GVal = ((rtoInputs.iA * (rtoInputs.iB/100)) * (rtoInputs.iC + rtoInputs.iD + rtoInputs.iE)); //Monthly RTO Loss

        

        let HVal  = parseFloat(GVal).toFixed(2) - [((rtoInputs.iA * (rtoInputs.iF/100)) * (rtoInputs.iC+rtoInputs.iD+rtoInputs.iE)) + ((((rtoInputs.iB-rtoInputs.iF) / 100) * rtoInputs.iA) * rtoInputs.iC)];
        
        

        const I = (parseFloat(HVal).toFixed(2) / rtoInputs.iA); //Per Order Saving

        //setRTOInpust({...rtoInputs, "iG": parseFloat(GVal).toFixed(2)});
        //setRTOInpust({...rtoInputs, "iH": parseFloat(HVal).toFixed(2)});
        //setRTOInpust({...rtoInputs, "iI": I});

        setGG(parseFloat(GVal).toFixed(2));
        setHH(parseFloat(HVal).toFixed(2));
        setII(parseFloat(I).toFixed(2));

        console.log("Savings... ", {hh, hh, ii});

      }

    }

  return (
    <div className="App">

      <div className="header">
        <div className='flex flex-col justify-start md:items-start w-full'>
          <div className="flex justify-center md:items-start">
            <h2 className="text-5xl font-bold text-[#2b3674] mt-8 md:ml-52">RTO Calculator</h2>
          </div>
        </div>
      </div>

      <div className='conatiner md:flex justify-center items-start w-full mt-6'>
        <div className='md:bg-white rounded-3xl md:mx-4'>
          <h2 className='text-[#2b3674] p-8 border-b-2 border-[#e9edf7] text-xl'>Fill out the information below know how much you can SAVE!</h2>
          <div className='flex'>
              <div className='mt-6 px-4 w-full'>
                <h2 className='text-[#2b3674] flex'> Total umber of monthly orders</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 w-full my-2' type='number' placeholder='Enter Order Value' name='iA' onChange={handleOnChange}></input>
              </div>              
              <div className='mt-6 px-4 w-full'>
                <h2 className='text-[#2b3674] flex'> Current RTO Percentage %</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 w-full my-2' type='number' placeholder='Enter %' name='iB' onChange={handleOnChange}></input>
              </div>
          </div>

          <div className='md:flex'>
            <div className='mt-6 px-4 w-full'>
                <h2 className='text-[#2b3674] flex'> Avg. forword shipping cost</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 w-full my-2' type='number' placeholder='Enter cost' name='iC' onChange={handleOnChange}></input></div>
            <div className='mt-6 px-4 w-full'>
                <h2 className='text-[#2b3674] flex'> Avg. RTO hipping cost</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 w-full my-2' type='number' placeholder='Enter cost' name='iD' onChange={handleOnChange}></input></div>
            <div className='mt-6 px-4 w-full'>
                <h2 className='text-[#2b3674] flex'> Avg. margin per order</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 w-full my-2' type='number' placeholder='Enter margin' name='iE' onChange={handleOnChange}></input></div>
          </div>

          <div className='mt-6 w-full'>
            <div className='w-full px-4'>
              <h2 className='flex text-[#2b3674]'> Monthly RTO Loss</h2>
              <input className='flex my-2 p-3 md:w-auto w-full ' placeholder='0.00' disabled name='iG' value={gg} />
              <h2 className='border-b-2 border-[#e9edf7]'></h2>
            </div>
          </div>

          <div className='mt-6 px-4 w-full my-6'>
                <h2 className='text-[#2b3674] flex'> If RTO reduse to:</h2>
                <input className='border rounded-xl border-[#e9edf7] p-3 flex my-2 md:w-auto w-full' type='number' placeholder='Enter %' name='iF' onChange={handleOnChange} />
          </div>
        </div>

        <div className='md:bg-white rounded-3xl md:mx-2 md:pr-20'>
          <div className='mt-6 px-4 w-full my-6'>
              <h2 className='text-[#2b3674] flex'> Total Monthly Savings</h2>
              <input className='border rounded-xl border-[#e9edf7] p-3 flex my-2 md:w-auto w-full' disabled placeholder='0.00' name='iH' value={hh} />
          </div>
          <div className='mt-6 px-4 w-full my-6'>
              <h2 className='text-[#2b3674] flex'> Per Order Saving</h2>
              <input className='border rounded-xl border-[#e9edf7] p-3 flex my-2 md:w-auto w-full' disabled placeholder='0.00' name='iI' value={ii} />
          </div>
        </div>
      </div>

      <div className='footer flex justify-center items-baseline mt-20'>
          <h2 className='text-md text-[#9098c1] font-bold text-lg'>Openleaf</h2>
      </div>

    </div>
  );
}

export default App;
